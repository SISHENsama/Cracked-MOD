var scriptName = "VulcanHop";
var scriptVersion = 1.0; 
var scriptAuthor = "TheLiquidD's Friend";

var VulcanHop = new VulcanHop();
var Client;

var airMoves = 0;

function VulcanHop() {

    this.getName = function() {
        return "VulcanHop";
    };

    this.getDescription = function() {
        return "Yport for VulcanAC";
    };

    this.getCategory = function() {
        return "Movement";
    };

    this.onUpdate = function() {

        if (!(mc.gameSettings.keyBindForward.isKeyDown() && !mc.gameSettings.keyBindJump.isKeyDown())) {
            return;
        }

        if (mc.thePlayer.onGround) {
            airMove = 0;
            mc.thePlayer.jump();
            return; 
        }

        mc.thePlayer.timerSpeed = 1;

        if (airMoves >= 2) {

            mc.thePlayer.jumpMovementFactor = 0.0230;

            if (airMoves >= 13 && airMoves % 8 == 0.0) {
                mc.thePlayer.motionY = -0.32 - 0.004 * Math.random();
                mc.thePlayer.jumpMovementFactor = 0.0260;
            }
        
        }

        airMoves++;
    }


}

function onLoad() {
    //i recommend you should setting timer 1.0
};

function onEnable() {
    exampleModuleClient = moduleManager.registerModule(VulcanHop);
};

function onDisable() {
    mc.thePlayer.timerSpeed = 1;
    moduleManager.unregisterModule(Client);
};