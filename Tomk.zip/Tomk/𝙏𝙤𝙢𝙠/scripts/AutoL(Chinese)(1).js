var scriptName = "AutoL";
var scriptVersion = 1.0;
var scriptAuthor = "No People";


var CNM = ["[16] Kill You"];
var target;
   
var EntityPlayer = Java.type('net.minecraft.entity.player.EntityPlayer');


function AutoL() {
    this.getName = function () {
        return "AutoLose";
    };

    this.getDescription = function () {
        return "Kill a player say L";
    };

    this.getCategory = function () {
        return "Misc";
    };
	
	this.getTag = function() {
		return "kill%0";
	}
	
    this.onEnable = function () {
		target = null;        
    };


    
    this.onAttack = function (event) {
		if(event.getTargetEntity() instanceof EntityPlayer){
			target = event.getTargetEntity();
		}

    };

    this.onUpdate = function () {		
        if (target != null) {
            if (target.isDead) {
                mc.thePlayer.sendChatMessage("[Tomk.c1n.cn] -正版#5/9 V0.25-" );
                target = null;
            }
        }
		
    };

}

var AutoLModule = new AutoL();

var AutoLModuleClient;

function onLoad() {

}

function onEnable() {
    AutoLModuleClient = moduleManager.registerModule(AutoLModule);
}

function onDisable() {
    moduleManager.unregisterModule(AutoLModuleClient);
}