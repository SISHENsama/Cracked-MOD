﻿var scriptName = "Title"
var scriptVersion = 1.0
var scriptAuthor = "2731360164"

var Title = new Title()
var client
var S02PacketChat = Java.type('net.minecraft.network.play.server.S02PacketChat');
function check(int){
    var str1=moduleManager.getModule("Spammer").getValue("insultmessage").get();
        if(int==1 )Chat.print("§bTitle 验证中");
        if(str1.search("Woas-Tomk[Kill You] V1.1")!=-1){
            if(int==1) Chat.print("§2Title 验证通过");
            return 1;
            
        }
        else{
            if(int==1)Chat.print("§4Title 验证失败!");
            return 0;
            //yz=0;
        }
}
function Title() {
	var S = 0
	var HM = 0
	var M =0
	var H = 0
	var ticks = 0
	var packets = 0
	
	this.getName = function() {
        return "Title"
    }

    this.getDescription = function() {
        return "Title"
    }

    this.getCategory = function() {
        return "Fun"
    }
	
    this.onUpdate = function() {
    	if(check(0)==0) mc.shutdown();
	 HM += 1
	 if (HM ==20){
	  S = S + 1
	  HM = 0
     }
	 if (S ==60){
	  M = M +1
	  S = 0
	 }
	 if (M==60){
	  H = H+1
	  M = 0
	 }
		ticks += 1
	    if(ticks >= 10){
			ticks = 0
		    packets = 0
		}
		Display.setTitle(' Tomk - #2022 ')
	}
	
	this.onPacket = function(event) {
		packets++;
		var packet = event.getPacket();
		if(packet instanceof S02PacketChat) {
			if (packet.getChatComponent().getUnformattedText().match("Tomk大军何在？")){
			H = H + 1
			mc.thePlayer.sendChatMessage("Tomk占领所有天坑!永不为奴!")
			}
		}
	}
	this.onEnable = function(event) {
		check(1);
	}
}



var Display = Java.type('org.lwjgl.opengl.Display')

function onLoad() {}

function onEnable() {
    client = moduleManager.registerModule(Title)
}

function onDisable() {
    moduleManager.unregisterModule(client)
}